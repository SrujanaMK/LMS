<img src="https://user-images.githubusercontent.com/51323434/167377608-1c777b54-b6b9-4760-8854-107e191302fb.png" width="193" height="411" align="right"/>

# LMS
###### Android app for _Library Management System_ [[lms_django](https://github.com/theDebonair/lms_django/)] project. This app is developed to provide LMS users to access LMS web app on their android smartphones.

## Things to know:
- ###### IDE: Android Studio
- ###### Language: JAVA

## P.S:
- ###### Feel free to make suggestions, report bugs on this project's [discussions](https://github.com/theDebonair/lms_android/discussions) tab.
